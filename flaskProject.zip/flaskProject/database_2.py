import pymysql
from flask import (Flask, request, render_template, redirect, url_for, flash)
app = Flask(__name__)


def connection():
    return pymysql.connect(
        host="localhost",
        user="root",
        password="root",
        cursorclass=pymysql.cursors.DictCursor,
        db="pythondb"
    )


@app.route("/")
def home():
    return redirect(url_for('load'))


@app.route("/register")
def load():
    return render_template("register.html")


@app.route("/login", methods=['POST', 'GET'])
def register():
    first = request.form.get("fName")
    last = request.form.get("lName")
    email = request.form.get("emailId")
    pswd = request.form.get("password")

    db_connect = connection()
    db_cursor = db_connect.cursor()
    db_cursor.execute("INSERT INTO login_table (first_name, last_name, password, email) "
                      "VALUES ('{}', '{}', '{}', '{}')".format(first, last, pswd, email))
    db_cursor.close()
    db_connect.commit()
    db_connect.close()
    return render_template("login.html")


@app.route("/loading")
def loading():
    return render_template("login.html")


@app.route("/welcome", methods=['POST', 'GET'])
def login():
    un = request.form.get("uName")
    passwd = request.form.get("password")
    login_conn = connection()
    login_cursor = login_conn.cursor()
    login_cursor.execute("SELECT * FROM login WHERE email = '{}'".format(un))
    details = login_cursor.fetchall()
    login_cursor.close()
    login_conn.close()
    if un == details['email'] and passwd == details['password']:
        return redirect('/home')
    else:
        flash("SORRY!!!! Invalid USER ID or PASSWORD")
        return redirect("/loading")



@app.route("/home")
def view():
    view_conn = connection()
    view_cursor = view_conn.cursor()
    view_cursor.execute("SELECT * FROM login")
    data = view_cursor.fetchall()
    print(data)
    print(type(data))
    view_cursor.close()
    view_conn.close()

    return render_template("hello.html", data=data)


if __name__ == "__main__":
    app.run(debug=True, port=5000, threading=True)
