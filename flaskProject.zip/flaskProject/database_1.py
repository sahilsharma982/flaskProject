from flask import Flask, render_template, redirect, url_for, request
import pymysql
app = Flask(__name__)


def db_connect():
    return pymysql.connect(
        host="localhost",
        user="root",
        password="root",
        cursorclass=pymysql.cursors.DictCursor,
        db="pythondb"
    )


@app.route('/')
def load_page():
    return render_template("welcome.html")


@app.route("/register")
def register():
    return render_template("registration.html")


@app.route('/registration', methods=['POST', 'GET'])
def details():
    firstname = request.form.get('firstName')
    lastname = request.form.get('lastName')
    gender = request.form.get('gender')
    username = request.form.get('userName')
    password = request.form.get('password')
    address = request.form.get('address')
    state = request.form.get('state')
    hobbies = request.form.getlist('hobbies')
    hobby = ("-".join(hobbies))

    memory = db_connect()
    cursor1 = memory.cursor()

    cursor1.execute("Insert into loginmaster (first_name, last_name, gender, user_name, password, "
                    "address,state, hobbies) VALUES ('{}', '{}', '{}', '{}', '{}', '{}', '{}', '{}')"
                    .format(firstname, lastname, gender, username, password, address, state, hobby))

    cursor1.close()
    memory.commit()
    memory.close()

    return redirect(url_for("view_data"))


@app.route("/view", methods=['GET'])
def view_data():
    db_object = db_connect()
    db_cursor = db_object.cursor()
    db_cursor.execute("Select id, first_name, last_name, gender, address, state, hobbies from loginmaster")
    data = db_cursor.fetchall()
    print(data)
    print(type(data))
    db_cursor.close()
    db_object.close()
    return render_template("display.html", data=data)


@app.route("/delete", methods=['GET'])
def delete():
    reg_id = request.args.get("regId")
    del_obj = db_connect()
    del_cursor = del_obj.cursor()
    del_cursor.execute("Delete from loginmaster where id =('{}')".format(reg_id))
    del_cursor.close()
    del_obj.commit()
    del_obj.close()
    return redirect(url_for("view_data"))


@app.route("/edit", methods=['POST', 'GET'])
def edit():
    edit_id = request.args.get("regId")
    edit_obj = db_connect()
    edit_cursor = edit_obj.cursor()
    edit_cursor.execute("SELECT * FROM loginmaster WHERE id=('{}')".format(edit_id))
    data = edit_cursor.fetchall()
    edit_cursor.close()
    edit_obj.close()
    return render_template("edit.html", data=data)


@app.route("/update", methods=['POST'])
def update():
    update_id = request.form.get("regId")
    fn = request.form.get("fn")
    ln = request.form.get("ln")
    un = request.form.get("un")
    add = request.form.get("addr")
    update_obj = db_connect()
    update_cursor = update_obj.cursor()
    update_cursor.execute("UPDATE loginmaster SET first_name='{}', last_name='{}', user_name='{}',"
                          " address='{}' WHERE id=('{}')".format(fn, ln, un, add, update_id))
    update_obj.commit()
    update_cursor.close()
    update_obj.close()

    return redirect(url_for('view_data'))


if __name__ == "__main__":
    app.run(threaded=True, debug=True, port=5000)

