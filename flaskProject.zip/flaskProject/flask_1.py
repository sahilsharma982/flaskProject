from flask import Flask, render_template, request

app = Flask(__name__)


@app.route('/')
def load_page():
    return render_template("registration.html")


@app.route('/registration', methods=['POST', 'GET'])
def details():
    firstname = request.form.get('firstName')
    lastname = request.form.get('lastName')
    gender = request.form.get('gender')
    username = request.form.get('userName')
    password = request.form.get('password')
    address = request.form.get('address')
    state = request.form.get('state')
    hobbies = request.form.getlist('hobby')
    hobby = ("-".join(hobbies))
    return "First Name: {} <br> Last Name: {} <br> Gender: {} <br> User Name: {}" \
           "<br> Password: {} <br> Address: {} <br> State: {} <br> Hobbies: {}" \
        .format(firstname, lastname, gender, username, password, address, state, hobby)


if __name__ == "__main__":
    app.run(threaded=True, debug=True, port=5000)
