from flask import request, session, render_template, redirect, Flask, url_for, flash

app = Flask(__name__)


@app.route('/')
def fn1():
    return render_template('firstPage.html')


@app.route('/session-login', methods=['POST'])
def fn2():
    fn = request.form.get('fName')
    ln = request.form.get('lName')
    user = request.form.get('un')
    pswd = request.form.get('password')
    session['k1'] = fn, ln
    session['k2'] = user, pswd
    session['k4'] = " ".join(session['k1'])
    return render_template('secondPage.html')


@app.route('/session', methods=['POST'])
def fn3():
    un = request.form.get('emailId')
    pswd = request.form.get('password')
    session['k3'] = un, pswd
    print(type(session['k4']))
    if session['k3'] == session['k2']:
        return render_template('thirdPage.html')
    else:
        flash("Invalid User ID or Password")
        return redirect('/loadLogin')


@app.route('/loadLogin')
def fn5():
    return render_template("secondPage.html")


@app.route('/logout')
def fn4():
    return redirect(url_for('fn1'))


if __name__ == "__main__":
    app.run(debug=True, threaded=True, port=5000, host="localhost")
